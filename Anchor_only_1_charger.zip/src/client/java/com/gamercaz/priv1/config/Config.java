package com.gamercaz.priv1.config;

public class Config {
  public boolean enabled = true;
  public int maxCharges = 1;
}