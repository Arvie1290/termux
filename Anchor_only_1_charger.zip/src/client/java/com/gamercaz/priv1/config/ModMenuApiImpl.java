package com.gamercaz.priv1.config;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.text.Text;

public class ModMenuApiImpl implements ModMenuApi {

  public static Config config = new Config();

  @Override
  public ConfigScreenFactory<?> getModConfigScreenFactory() {
    return parent -> {
      ConfigBuilder builder = ConfigBuilder.create()
          .setParentScreen(parent)
          .setTitle(Text.literal("Respawn Anchor Limiter"));

      ConfigEntryBuilder entryBuilder = builder.entryBuilder();
      ConfigCategory general = builder.getOrCreateCategory(Text.literal("General"));

      general.addEntry(entryBuilder.startBooleanToggle(Text.literal("Enable Mod"), config.enabled)
          .setDefaultValue(true)
          .setSaveConsumer(newValue -> config.enabled = newValue)
          .build());

      general.addEntry(entryBuilder.startIntSlider(Text.literal("Max Charge Allowed"), config.maxCharges, 1, 4)
          .setDefaultValue(1)
          .setSaveConsumer(newValue -> config.maxCharges = newValue)
          .build());

      return builder.build();
    };
  }
}