package com.gamercaz.priv1;

import com.gamercaz.priv1.config.ModMenuApiImpl;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;

public class Priv1Client implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
			if (!ModMenuApiImpl.config.enabled) {
				return ActionResult.PASS;
			}

			if (player.getStackInHand(hand).isOf(Items.GLOWSTONE)) {
				BlockState state = world.getBlockState(hitResult.getBlockPos());

				if (state.isOf(Blocks.RESPAWN_ANCHOR)) {
					// Jika player jongkok/sneak, izinkan seperti biasa (menaruh blok di luar anchor)
					if (player.isSneaking()) {
						return ActionResult.PASS;
					}

					int currentCharges = state.get(RespawnAnchorBlock.CHARGES);
					int maxAllowed = ModMenuApiImpl.config.maxCharges;

					// Jika charge sudah melebih/sama dengan limit, blokir pengisian
					if (currentCharges >= maxAllowed) {
						return ActionResult.FAIL;
					}
				}
			}

			return ActionResult.PASS;
		});
	}
}