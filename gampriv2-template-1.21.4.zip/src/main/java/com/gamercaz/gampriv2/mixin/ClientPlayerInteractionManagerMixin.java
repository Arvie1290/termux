package com.gamercaz.gampriv2.mixin;

import com.gamercaz.gampriv2.GamPriv2Client;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientPlayerInteractionManager.class)
public class ClientPlayerInteractionManagerMixin {

  @Shadow @Final private MinecraftClient client;

  @Inject(method = "interactBlock", at = @At("HEAD"))
  private void trackPlacedAnchor(ClientPlayerEntity player, Hand hand, BlockHitResult hitResult, CallbackInfoReturnable<ActionResult> cir) {
    if (client.world == null || player == null) return;

    ItemStack heldItem = player.getStackInHand(hand);

    // Cek jika item di tangan adalah Respawn Anchor
    if (heldItem.isOf(Items.RESPAWN_ANCHOR)) {
      ItemUsageContext usageContext = new ItemUsageContext(player, hand, hitResult);
      ItemPlacementContext placementContext = new ItemPlacementContext(usageContext);

      // getBlockPos() milik ItemPlacementContext secara otomatis menghitung lokasi blok
      // apakah menimpa Api/Rumput/Air ATAU menempel di sisinya!
      BlockPos targetPos = placementContext.getBlockPos();

      if (placementContext.canPlace()) {
        // Simpan KEDUA lokasi (posisi target penempatan DAN posisi klik asli)
        // untuk mengantisipasi desync server/client
        GamPriv2Client.PLAYER_PLACED_ANCHORS.add(targetPos);
        GamPriv2Client.PLAYER_PLACED_ANCHORS.add(hitResult.getBlockPos());
      }
    }
  }
}