package com.gamercaz.gampriv2;

import com.gamercaz.gampriv2.config.ModConfig;
import me.shedaniel.autoconfig.AutoConfig;
import me.shedaniel.autoconfig.serializer.JanksonConfigSerializer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.lang.reflect.Constructor;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class GamPriv2Client implements ClientModInitializer {

  public static ModConfig CONFIG;
  public static final Set<BlockPos> PLAYER_PLACED_ANCHORS = new HashSet<>();
  private static final Set<BlockPos> GLOWED_ANCHORS = new HashSet<>();

  private static int interactCooldown = 0;
  private static int savedOriginalSlot = -1;
  private static int switchBackDelay = -1;

  @Override
  public void onInitializeClient() {
    AutoConfig.register(ModConfig.class, JanksonConfigSerializer::new);
    CONFIG = AutoConfig.getConfigHolder(ModConfig.class).getConfig();

    ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
  }

  private void onTick(MinecraftClient client) {
    if (client.player == null || client.world == null || client.interactionManager == null) {
      return;
    }

    if (interactCooldown > 0) {
      interactCooldown--;
    }

    if (switchBackDelay > 0) {
      switchBackDelay--;
    } else if (switchBackDelay == 0) {
      if (savedOriginalSlot != -1) {
        changeSlot(client, savedOriginalSlot);
        savedOriginalSlot = -1;
      }
      switchBackDelay = -1;
    }

    if (CONFIG.shield.dontDoAnythingOnMenu && client.currentScreen != null) {
      return;
    }

    Iterator<BlockPos> iterator = PLAYER_PLACED_ANCHORS.iterator();
    while (iterator.hasNext()) {
      BlockPos anchorPos = iterator.next();
      if (!client.world.getBlockState(anchorPos).isOf(Blocks.RESPAWN_ANCHOR)) {
        iterator.remove();
        GLOWED_ANCHORS.remove(anchorPos);
      }
    }

    HitResult hit = client.crosshairTarget;
    if (hit == null) return;

    // ----------------------------------------------------
    // 1. ANCHOR LOGIC
    // ----------------------------------------------------
    if (hit.getType() == HitResult.Type.BLOCK) {
      BlockHitResult blockHit = (BlockHitResult) hit;
      BlockPos pos = blockHit.getBlockPos();

      if (client.world.getBlockState(pos).isOf(Blocks.RESPAWN_ANCHOR)) {
        PLAYER_PLACED_ANCHORS.add(pos);

        BlockState state = client.world.getBlockState(pos);
        int charges = state.get(RespawnAnchorBlock.CHARGES);

        if (CONFIG.anchor.autoGlow && charges == 0 && interactCooldown == 0) {
          int glowstoneSlot = findHotbarItem(client, Items.GLOWSTONE);
          if (glowstoneSlot != -1) {
            changeSlot(client, glowstoneSlot);

            ActionResult result = client.interactionManager.interactBlock(client.player, Hand.MAIN_HAND, blockHit);
            if (result.isAccepted()) {
              client.player.swingHand(Hand.MAIN_HAND);
              GLOWED_ANCHORS.add(pos);
              interactCooldown = 2;
            }
          }
        }
        else if (CONFIG.anchor.autoAnchor && charges >= 1 && interactCooldown == 0) {
          boolean shouldExplode = true;

          if (CONFIG.anchor.anchorIfPlayerNearby) {
            shouldExplode = isOtherPlayerNearby(client, pos, 5.0);
          }

          if (shouldExplode) {
            if (CONFIG.anchor.safetyAnchor) {
              placeSafetyGlowstoneInFront(client, pos);
            }

            int safeSlot = findNonGlowstoneSlot(client);
            if (safeSlot != -1) {
              changeSlot(client, safeSlot);
            }

            ActionResult result = client.interactionManager.interactBlock(client.player, Hand.MAIN_HAND, blockHit);
            if (result.isAccepted()) {
              client.player.swingHand(Hand.MAIN_HAND);
              interactCooldown = 2;
            }
          }
        }
      }
    }

    // ----------------------------------------------------
    // 2. SHIELD LOGIC
    // ----------------------------------------------------
    if (CONFIG.shield.autoBreakShield && hit.getType() == HitResult.Type.ENTITY) {
      EntityHitResult entityHit = (EntityHitResult) hit;

      if (entityHit.getEntity() instanceof LivingEntity target) {
        if (target.isBlocking()) {
          int axeSlot = findAxeInHotbar(client);
          if (axeSlot != -1) {
            int currentSlot = client.player.getInventory().selectedSlot;

            if (currentSlot != axeSlot && savedOriginalSlot == -1) {
              savedOriginalSlot = currentSlot;
            }

            changeSlot(client, axeSlot);
            client.interactionManager.attackEntity(client.player, target);
            client.player.swingHand(Hand.MAIN_HAND);

            if (CONFIG.shield.switchBackSlot && savedOriginalSlot != -1) {
              switchBackDelay = Math.max(1, CONFIG.shield.switchBackDelayTicks);
            } else {
              savedOriginalSlot = -1;
            }
          }
        } else {
          if (switchBackDelay <= 0 && savedOriginalSlot != -1) {
            changeSlot(client, savedOriginalSlot);
            savedOriginalSlot = -1;
          }
        }
      }
    } else {
      if (switchBackDelay <= 0 && savedOriginalSlot != -1) {
        changeSlot(client, savedOriginalSlot);
        savedOriginalSlot = -1;
      }
    }
  }

  private void placeSafetyGlowstoneInFront(MinecraftClient client, BlockPos anchorPos) {
    int glowstoneSlot = findHotbarItem(client, Items.GLOWSTONE);
    if (glowstoneSlot == -1) return;

    Direction playerFacing = client.player.getHorizontalFacing();
    BlockPos frontPos = anchorPos.offset(playerFacing.getOpposite());

    if (client.world.getBlockState(frontPos).isAir()) {
      changeSlot(client, glowstoneSlot);

      Vec3d targetVec = Vec3d.ofCenter(frontPos);
      double dx = targetVec.x - client.player.getX();
      double dy = targetVec.y - client.player.getEyeY();
      double dz = targetVec.z - client.player.getZ();
      double distance = Math.sqrt(dx * dx + dz * dz);

      float yaw = (float) (Math.atan2(dz, dx) * (180 / Math.PI)) - 90.0F;
      float pitch = (float) (-(Math.atan2(dy, distance) * (180 / Math.PI)));

      if (client.getNetworkHandler() != null) {
        sendSafeLookPacket(client, yaw, pitch);
      }

      BlockHitResult safetyHit = new BlockHitResult(
              targetVec, playerFacing, frontPos, false
      );
      client.interactionManager.interactBlock(client.player, Hand.MAIN_HAND, safetyHit);
      client.player.swingHand(Hand.MAIN_HAND);
    }
  }

  private void sendSafeLookPacket(MinecraftClient client, float yaw, float pitch) {
    for (Constructor<?> ctor : PlayerMoveC2SPacket.LookAndOnGround.class.getConstructors()) {
      Class<?>[] paramTypes = ctor.getParameterTypes();
      try {
        if (paramTypes.length == 4) {
          client.getNetworkHandler().sendPacket((PlayerMoveC2SPacket.LookAndOnGround) ctor.newInstance(yaw, pitch, client.player.isOnGround(), client.player.horizontalCollision));
          return;
        } else if (paramTypes.length == 3) {
          client.getNetworkHandler().sendPacket((PlayerMoveC2SPacket.LookAndOnGround) ctor.newInstance(yaw, pitch, client.player.isOnGround()));
          return;
        }
      } catch (Exception ignored) {}
    }
  }

  private void changeSlot(MinecraftClient client, int slot) {
    if (client.player != null && slot >= 0 && slot < 9) {
      if (client.player.getInventory().selectedSlot != slot) {
        client.player.getInventory().selectedSlot = slot;

        if (client.getNetworkHandler() != null) {
          client.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
        }
      }
    }
  }

  private boolean isOtherPlayerNearby(MinecraftClient client, BlockPos pos, double radius) {
    Box area = new Box(pos).expand(radius);
    List<PlayerEntity> players = client.world.getEntitiesByClass(PlayerEntity.class, area, p -> p != client.player && p.isAlive());
    return !players.isEmpty();
  }

  private int findNonGlowstoneSlot(MinecraftClient client) {
    int currentSlot = client.player.getInventory().selectedSlot;
    ItemStack currentStack = client.player.getInventory().getStack(currentSlot);

    if (!currentStack.isOf(Items.GLOWSTONE)) {
      return currentSlot;
    }

    for (int i = 0; i < 9; i++) {
      ItemStack stack = client.player.getInventory().getStack(i);
      if (!stack.isOf(Items.GLOWSTONE)) {
        return i;
      }
    }
    return -1;
  }

  private int findHotbarItem(MinecraftClient client, net.minecraft.item.Item item) {
    for (int i = 0; i < 9; i++) {
      ItemStack stack = client.player.getInventory().getStack(i);
      if (stack.isOf(item)) {
        return i;
      }
    }
    return -1;
  }

  private int findAxeInHotbar(MinecraftClient client) {
    for (int i = 0; i < 9; i++) {
      ItemStack stack = client.player.getInventory().getStack(i);
      if (stack.getItem() instanceof AxeItem) {
        return i;
      }
    }
    return -1;
  }
}