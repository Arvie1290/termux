package com.gamercaz.gampriv2.config;

import me.shedaniel.autoconfig.ConfigData;
import me.shedaniel.autoconfig.annotation.Config;
import me.shedaniel.autoconfig.annotation.ConfigEntry;

@Config(name = "gampriv2")
public class ModConfig implements ConfigData {

  @ConfigEntry.Category("anchor")
  @ConfigEntry.Gui.CollapsibleObject
  public AnchorConfig anchor = new AnchorConfig();

  @ConfigEntry.Category("shield")
  @ConfigEntry.Gui.CollapsibleObject
  public ShieldConfig shield = new ShieldConfig();

  public static class AnchorConfig {
    public boolean autoGlow = true;
    public boolean autoAnchor = true;
    public boolean anchorIfPlayerNearby = false;
    public boolean safetyAnchor = true;
  }

  public static class ShieldConfig {
    public boolean autoBreakShield = true;
    public boolean dontDoAnythingOnMenu = true;
    public boolean switchBackSlot = true;
    public int switchBackDelayTicks = 2;
  }
}