import datetime
import os
import threading
import time
from logger import log

# --- KONSTANTA & KONFIGURASI ---
DEFAULT_SCAN_INTERVAL = 1.0  # Time sleep 1 detik biar ringan
DEFAULT_SAFE_DISTANCE = 5.0  # Jarak disconnect (blok)
DEFAULT_SAFE_DIST_SQ = DEFAULT_SAFE_DISTANCE**2  # 25.0 (Optimasi CPU)


class PlayerDetector:

    def __init__(
        self,
        bot,
        trusted_players=None,
        scan_interval=DEFAULT_SCAN_INTERVAL,
        safe_distance=DEFAULT_SAFE_DISTANCE,
    ):
        self.bot = bot

        # 1. trusted_players pakai Set O(1)
        self.trusted_players = {
            str(p).lower() for p in (trusted_players or [])
        }

        self.scan_interval = scan_interval
        self.disconnect_threshold = safe_distance
        self.disconnect_threshold_sq = safe_distance**2

        self.is_detecting = False
        self.filter_trusted = False
        self.scan_thread = None

        self.logged_players = set()
        self.log_dir = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "log"
        )
        if not os.path.exists(self.log_dir):
            os.makedirs(self.log_dir)

    def start_detection(self, filter_trusted=False):
        """Memulai modul deteksi player"""
        if self.is_detecting:
            log("WARN", "Player Detector sudah berjalan!")
            return

        self.is_detecting = True
        self.filter_trusted = filter_trusted
        self.logged_players.clear()

        mode_str = (
            "TRUSTED_PLAYERS (Filter On)"
            if filter_trusted
            else "ALL PLAYERS (No Filter)"
        )
        log("ACTION", f"Player Detector DIAKTIFKAN. Mode: {mode_str}")
        log(
            "ACTION",
            f"Auto-Disconnect Safe Distance: {self.disconnect_threshold} blok",
        )

        self.scan_thread = threading.Thread(
            target=self._scan_loop, daemon=True
        )
        self.scan_thread.start()

    def stop_detection(self):
        """Mematikan radar deteksi dan menunggu thread selesai (join)"""
        if self.is_detecting:
            self.is_detecting = False

            # 5. Thread stop dengan join bersih
            if self.scan_thread and self.scan_thread.is_alive():
                self.scan_thread.join(timeout=1.5)

            log("ACTION", "Player Detector DIMATIKAN.")

    def _scan_loop(self):
        """Loop utama scanning player"""
        while self.is_detecting:
            try:
                self._check_nearby_players()
            except Exception as e:
                # 4. Error logging spesifik
                log("DEBUG", f"Error pada Loop Player Detector: {e}")

            # 2. Interval scan 1 detik
            time.sleep(self.scan_interval)

    def _check_nearby_players(self):
        """Memeriksa player di sekitar bot"""
        if not self.bot:
            return

        bot_entity = getattr(self.bot, "entity", None)
        if not bot_entity or not hasattr(bot_entity, "position"):
            return

        b_pos = bot_entity.position
        if b_pos is None:
            return

        entities = getattr(self.bot, "entities", None)
        if not entities:
            return

        bot_username = str(getattr(self.bot, "username", "")).lower()

        try:
            entity_items = list(entities.items())
        except Exception as e:
            log("DEBUG", f"Gagal mengambil items entities: {e}")
            return

        current_visible_players = set()

        for entity_id, player_entity in entity_items:
            try:
                if not player_entity:
                    continue

                if str(getattr(player_entity, "type", "")) != "player":
                    continue

                p_name_raw = getattr(player_entity, "username", None)
                if not p_name_raw:
                    continue

                player_name = str(p_name_raw)
                p_name_lower = player_name.lower()

                if p_name_lower == bot_username:
                    continue

                # Tandai player saat ini ada di render distance
                current_visible_players.add(player_name)

                # Filter Trusted (O(1) Set Lookup)
                if self.filter_trusted and p_name_lower in self.trusted_players:
                    continue

                p_pos = getattr(player_entity, "position", None)
                if not p_pos:
                    continue

                dx = float(p_pos.x) - float(b_pos.x)
                dy = float(p_pos.y) - float(b_pos.y)
                dz = float(p_pos.z) - float(b_pos.z)

                # 3. Hitung Jarak Kuadrat (Tanpa sqrt)
                dist_sq = dx * dx + dy * dy + dz * dz

                # 6. Log player baru / re-logged
                if player_name not in self.logged_players:
                    self.logged_players.add(player_name)
                    self._create_player_log(player_entity, player_name, p_pos)
                    self._alert_trusted_players(player_name, urgent=False)

                # Emergency Auto-Disconnect (dist_sq <= threshold^2)
                if dist_sq <= self.disconnect_threshold_sq:
                    actual_dist = (
                        dist_sq**0.5
                    )  # Hitung akar HANYA saat butuh nge-log
                    log(
                        "WARN",
                        f"ALERT! Player '{player_name}' terdeteksi sangat dekat ({actual_dist:.2f}m <= {self.disconnect_threshold}m)! Mengeluarkan bot...",
                    )

                    self._alert_trusted_players(player_name, urgent=True)
                    self.stop_detection()

                    try:
                        self.bot.quit(
                            f"Auto-disconnect: Player nearby within {actual_dist:.2f} blocks!"
                        )
                    except Exception as e:
                        log(
                            "DEBUG",
                            f"Gagal quit via bot.quit: {e}, memaksa socket end",
                        )
                        if hasattr(self.bot, "_client") and self.bot._client:
                            self.bot._client.end()
                    return

            except Exception as e:
                # 4. Catch-all per entity dengan log debug
                log("DEBUG", f"Error memproses entity {entity_id}: {e}")
                continue

        # 6. Hapus player dari logged_players jika mereka sudah keluar dari render distance (agar jika reconnect/kembali ter-log ulang)
        self.logged_players.intersection_update(current_visible_players)

    def _alert_trusted_players(self, target_player, urgent=False):
        """Kirim pesan /msg ke TRUSTED_PLAYERS"""
        if not self.trusted_players:
            return

        prefix = "URGENT! " if urgent else ""
        msg = f"{prefix}Hey!, kemungkinan base mu ketahuan!, Nama Player: {target_player}"

        for trusted in self.trusted_players:
            try:
                self.bot.chat(f"/msg {trusted} {msg}")
            except Exception as e:
                log("ERROR", f"Gagal kirim /msg ke {trusted}: {e}")

    def _create_player_log(self, entity, player_name, position):
        """9. Membuat file log terdeteksi lengkap dengan metadata (UUID, Yaw, Pitch, Ping, Health)"""
        try:
            now = datetime.datetime.now()
            filename = f"playernear_{now.strftime('%Y%m%d_%H%M%S')}.log"
            filepath = os.path.join(self.log_dir, filename)

            # Extra metadata dari entity
            server_ver = str(getattr(self.bot, "version", "Unknown"))
            uuid = str(getattr(entity, "uuid", "Unknown"))
            yaw = float(getattr(entity, "yaw", 0.0))
            pitch = float(getattr(entity, "pitch", 0.0))
            health = getattr(entity, "health", "Unknown/N/A")
            ping = getattr(entity, "ping", "N/A")

            log_content = [
                "============================================",
                "               PLAYER DETECTED              ",
                "============================================",
                f"Timestamp       : {now.strftime('%Y-%m-%d %H:%M:%S')}",
                f"Server Version  : {server_ver}",
                f"Player Name     : {player_name}",
                f"UUID            : {uuid}",
                f"Health          : {health}",
                f"Ping            : {ping} ms",
                "--------------------------------------------",
                "POSITION & ROTATION:",
                f"X               : {position.x:.2f}",
                f"Y               : {position.y:.2f}",
                f"Z               : {position.z:.2f}",
                f"Yaw             : {yaw:.2f}",
                f"Pitch           : {pitch:.2f}",
                "============================================",
            ]

            with open(filepath, "w", encoding="utf-8") as f:
                f.write("\n".join(log_content))

            log("ACTION", f"Log Player berhasil dibuat: {filename}")
        except Exception as e:
            log("ERROR", f"Gagal membuat file log: {e}")
