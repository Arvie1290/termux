#!/bin/bash

export PYTHONDONTWRITEBYTECODE=1

# Lokasi python di dalam venv
VENV_PYTHON="./venv/bin/python3"

if [ -f "$VENV_PYTHON" ]; then
    PYTHON_EXEC="$VENV_PYTHON"
else
    PYTHON_EXEC="python3"
fi

while true; do
    rm -rf __pycache__

    echo "=================================================="
    echo "🚀 Menjalankan bot-mc.py (Linux Mint Venv)..."
    echo "=================================================="

    # HAPUS 2>/dev/null agar pesan error terlihat jelas di terminal
    $PYTHON_EXEC bot-mc.py

    echo ""
    echo "--------------------------------------------------"
    read -n 1 -s -r -p "🔄 Press 'z' to clear & restart, 'q' to quit, or ANY key to restart..." input
    echo ""

    if [ "$input" = "q" ] || [ "$input" = "Q" ]; then
        echo "👋 Keluar dari launcher. Sampai jumpa!"
        break
    fi

    if [ "$input" = "z" ] || [ "$input" = "Z" ]; then
        clear
    fi
done
