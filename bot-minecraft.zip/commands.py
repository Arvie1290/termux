import sys
import threading
import time
from logger import log
from prompt_toolkit import PromptSession
from prompt_toolkit.patch_stdout import patch_stdout
from config import TRUSTED_PLAYERS  # Import Trusted Players
from player_detector import PlayerDetector  # Import Detector Module


class CommandHandler:

    def __init__(self, bot, gui_handler, macro_runner):
        self.bot = bot
        self.gui = gui_handler
        self.macro = macro_runner
        self.listener_started = False

        # Inisialisasi Player Detector Module
        self.detector = PlayerDetector(self.bot, TRUSTED_PLAYERS)

        # Mapping Command Internal
        self.commands = {
            "\\help": self._show_help,
            "\\run relxmc": lambda: self.macro.add_to_queue(
                self.macro.relxmc, "relxmc"
            ),
            "\\run afk": lambda: self.macro.add_to_queue(
                self.macro.afk, "afk"
            ),
            "\\klik kanan": self._click_right,
            "\\klik kiri": self._click_left,
            "\\klik esc": self._close_gui,
            "\\sneaktoggle on": self._sneak_on,
            "\\sneaktoggle off": self._sneak_off,
            "\\inv": self._show_inventory,
            "\\inventory": self._show_inventory,
            "\\coords": self._show_coords,
            "\\coord": self._show_coords,
            "\\pos": self._show_coords,
            "\\position": self._show_coords,
        }

    # ==========================================
    # HANDLER \detectplayer
    # ==========================================
    def _handle_detectplayer_cmd(self, raw_cmd: str):
        parts = raw_cmd.strip().split()

        # Kasus toggle off
        if len(parts) > 1 and parts[1].lower() in ["off", "stop"]:
            self.detector.stop_detection()
            return

        # Kasus \detectplayer trustplayer
        filter_trusted = False
        if len(parts) > 1 and parts[1].lower() in [
            "trustplayer",
            "trusted",
            "trustedplayer",
        ]:
            filter_trusted = True

        self.detector.start_detection(filter_trusted=filter_trusted)

    def _sneak_on(self):
        log("ACTION", "Sneak ON")
        self.bot.setControlState("sneak", True)

    def _sneak_off(self):
        log("ACTION", "Sneak OFF")
        self.bot.setControlState("sneak", False)

    def _show_inventory(self):
        log("SYSTEM", "Memindai inventory player...")
        if hasattr(self.gui, "show_player_inventory"):
            self.gui.show_player_inventory()
        else:
            log(
                "GUI_ERROR",
                "Method show_player_inventory belum ditambahkan di GUIHandler!",
            )

    def _show_help(self):
        log("HELP", "--- Daftar Perintah Bot ---")
        log("HELP", "\\help            - Menampilkan bantuan ini")
        log("HELP", "\\inv / \\inventory - Scan & tampilkan isi inventory bot")
        log("HELP", "\\coords / \\pos   - Tampilkan koordinat, world & dimensi")
        log(
            "HELP",
            "\\look <player>   - Arahkan pandangan ke player (--look=head/body/leg)",
        )
        log("HELP", "\\run relxmc      - Menjalankan macro AFK RelxMC")
        log("HELP", "\\run afk         - Menjalankan macro AFK dasar")
        log("HELP", "\\klik kanan/kiri - Simulasi interaksi")
        log("HELP", "\\klik esc        - Menutup GUI yang sedang terbuka")
        log("HELP", "\\sneaktoggle on/off - Mode jongkok")

    def _click_left(self):
        log("ACTION", "Klik Kiri")
        entity = self.bot.entityAtCursor(3.5)
        if entity:
            self.bot.attack(entity)
        else:
            self.bot.swingArm("right")

    def _click_right(self):
        log("ACTION", "Klik Kanan")
        entity = self.bot.entityAtCursor(3.5)
        if entity:
            log(
                "ACTION",
                f"Menginteraksi entity ID: {getattr(entity, 'id', 'Unknown')}",
            )
            self.bot.activateEntity(entity)
            return

        block = self.bot.blockAtCursor(4.5)
        if block and getattr(block, "type", 0) != 0:
            block_name = getattr(block, "name", "block")
            block_pos = getattr(block, "position", None)
            log(
                "ACTION",
                f"Menginteraksi blok: {block_name} di posisi {block_pos}",
            )

            def async_interact():
                try:
                    if block_pos:
                        self.bot.lookAt(
                            block_pos.offset(0.5, 0.5, 0.5), True
                        )
                    time.sleep(0.05)
                    self.bot.activateBlock(block)
                except Exception as e:
                    log("ACTION_ERROR", f"Gagal menginteraksi blok: {e}")

            threading.Thread(target=async_interact, daemon=True).start()
            return

        log("ACTION", "Menggunakan item di hotbar...")
        self.bot.activateItem()

    def _show_coords(self):
        """Mencetak posisi X, Y, Z, dimensi, dan nama world presisi dari server"""
        entity = getattr(self.bot, "entity", None)
        if not entity or not hasattr(entity, "position"):
            log("SYSTEM_WARN", "Posisi bot belum dapat dijangkau/dimuat.")
            return

        pos = entity.position
        x = getattr(pos, "x", 0.0)
        y = getattr(pos, "y", 0.0)
        z = getattr(pos, "z", 0.0)

        yaw = getattr(entity, "yaw", 0.0)
        pitch = getattr(entity, "pitch", 0.0)

        game_attr = getattr(self.bot, "game", None)

        # Ambil Nama World & Clean Prefix 'minecraft:'
        world_name = getattr(game_attr, "world", None)
        if not world_name:
            world_name = getattr(game_attr, "dimension", "unknown")

        clean_world = str(world_name).replace("minecraft:", "")
        server_brand = (
            getattr(game_attr, "serverBrand", "N/A") if game_attr else "N/A"
        )

        if "nether" in clean_world.lower():
            dim_icon = "🔥"
        elif "end" in clean_world.lower():
            dim_icon = "👁️"
        else:
            dim_icon = "🌲"

        print("\n" + "=" * 50)
        print(" 📍 KOORDINAT & LOKASI BOT SAAT INI")
        print("=" * 50)
        print(f" • World Name  : {dim_icon} {clean_world}")
        print(f" • Server Brand: {server_brand}")
        print(f" • X : {x:.3f}")
        print(f" • Y : {y:.3f}")
        print(f" • Z : {z:.3f}")
        print(
            f" • Position Format : /tp {x:.2f} {y:.2f} {z:.2f} (Yaw: {yaw:.1f}, Pitch: {pitch:.1f})"
        )
        print("=" * 50 + "\n")

    def _handle_look_cmd(self, raw_cmd: str):
        """
        Mengarahkan pandangan bot:
        1. Ke player: \\look <nama_player> [--look=head/body/leg]
        2. Rotasi relatif: \\look .rotasi <derajat> (misal: \\look .rotasi 90 atau \\look .rotasi -45)
        """
        import math

        parts = raw_cmd.strip().split()
        if len(parts) < 2:
            log("WARN", "Format salah! Gunakan: \\look <nama_player> [--look=head/body/leg] atau \\look .rotasi <derajat>")
            return

        arg_target = parts[1].lower()

        # ==========================================
        # CASE 1: PERINTAH ROTASI DERAZAT (\look .rotasi <derajat>)
        # ==========================================
        if arg_target in [".rotasi", ".rot"]:
            if len(parts) < 3:
                log("WARN", "Masukkan derajat rotasi! Contoh: \\look .rotasi 90")
                return

            try:
                degrees = float(parts[2])
            except ValueError:
                log("GUI_ERROR", f"Derajat '{parts[2]}' harus berupa angka!")
                return

            entity = getattr(self.bot, "entity", None)
            if not entity:
                log("WARN", "Data posisi bot belum siap/dimuat.")
                return

            # Konversi derajat ke Radian Mineflayer
            # Yaw di Mineflayer: 0 = South, Math.PI/2 = West, PI = North, 3*Math.PI/2 = East
            # Di Minecraft: Putar kanan (searah jarum jam) = Subtract Radian
            radians_offset = math.radians(degrees)
            current_yaw = getattr(entity, "yaw", 0.0)
            current_pitch = getattr(entity, "pitch", 0.0)

            # Hitung Yaw Baru (Minus karena arah sudut Minecraft terbalik dari standar Cartesian)
            new_yaw = current_yaw - radians_offset

            def do_rotate():
                try:
                    self.bot.look(new_yaw, current_pitch, True)
                    log("ACTION", f"Bot diputar {degrees}° ({'Kanan' if degrees > 0 else 'Kiri'}) | Yaw baru: {math.degrees(new_yaw):.1f}°")
                except Exception as e:
                    log("ACTION_ERROR", f"Gagal memutar pandangan bot: {e}")

            threading.Thread(target=do_rotate, daemon=True).start()
            return

        # ==========================================
        # CASE 2: PERINTAH LOOK KE PLAYER
        # ==========================================
        target_name = arg_target
        target_part = "head"

        # Parse flag --look= atau --type=
        for part in parts[2:]:
            lower_part = part.lower()
            if lower_part.startswith("--look=") or lower_part.startswith("--type="):
                val = lower_part.split("=")[1].strip()
                if val in ["head", "body", "leg", "feet"]:
                    target_part = "leg" if val == "feet" else val
                else:
                    log("GUI_ERROR", f"Flag target '{val}' tidak dikenal! Pilih: head, body, atau leg.")
                    return

        entities = getattr(self.bot, "entities", None)
        if not entities:
            log("WARN", "Data entities sekitar belum siap/dimuat.")
            return

        target_entity = None
        for ent_id in list(entities):
            ent = entities[ent_id]
            if not ent:
                continue
            ent_type = getattr(ent, "type", "")
            ent_username = getattr(ent, "username", None)
            ent_name = getattr(ent, "name", None)

            if ent_type == "player" or ent_username or ent_name == "player":
                name = str(ent_username or ent_name).lower()
                if name == target_name:
                    target_entity = ent
                    break

        if not target_entity:
            log("WARN", f"Player '{parts[1]}' tidak ditemukan di sekitar bot!")
            return

        # Offset tinggi Y
        y_offset = 1.62  # head
        if target_part == "body":
            y_offset = 0.90
        elif target_part == "leg":
            y_offset = 0.20

        pos = getattr(target_entity, "position", None)
        if not pos:
            log("WARN", f"Posisi player '{target_name}' tidak valid.")
            return

        target_pos = pos.offset(0, y_offset, 0)

        def do_look():
            try:
                self.bot.lookAt(target_pos, True)
                log("ACTION", f"Bot melihat ke {target_part.upper()} player '{getattr(target_entity, 'username', target_name)}'")
            except Exception as e:
                log("ACTION_ERROR", f"Gagal mengarahkan pandangan: {e}")

        threading.Thread(target=do_look, daemon=True).start()

    def _close_gui(self):
        if self.gui.active_window is not None:
            self.bot.closeWindow(self.gui.active_window)
            self.gui.active_window = None
            log("GUI", "GUI Berhasil ditutup.")
        else:
            log("GUI", "Tidak ada GUI yang terbuka.")

    def _handle_gui_input(self, user_input: str) -> bool:
        window = self.gui.active_window
        if not window:
            return False

        if user_input.upper() in ["EXIT", "CLOSE", "ESC"]:
            if window != getattr(self.bot, "inventory", None):
                self.bot.closeWindow(window)
            self.gui.active_window = None
            log("GUI", "GUI berhasil ditutup.")
            return True

        if user_input.upper().startswith("DROP_ALL_INV"):
            self._handle_drop_all_inv(user_input)
            return True

        parts = user_input.strip().split()
        if not parts:
            return False

        if len(parts) == 3 and parts[1].upper() == "TO":
            src_str, dst_str = parts[0], parts[2]
            if src_str.isdigit() and dst_str.isdigit():
                src_slot, dst_slot = int(src_str), int(dst_str)
                log(
                    "GUI",
                    f"Memindahkan item dari Slot [{src_slot}] TO [{dst_slot}]...",
                )

                def swap_async():
                    try:
                        self.bot.clickWindow(src_slot, 0, 0)
                        time.sleep(0.1)
                        self.bot.clickWindow(dst_slot, 0, 0)
                        time.sleep(0.1)
                        log("GUI", "Item berhasil dipindahkan.")

                        if window == getattr(self.bot, "inventory", None):
                            self.gui.show_player_inventory()
                    except Exception as e:
                        log("GUI_ERROR", f"Gagal swap item: {e}")

                threading.Thread(target=swap_async, daemon=True).start()
                return True

        slot_str = parts[0]
        mode = parts[1].upper() if len(parts) > 1 else "KIRI"

        if not slot_str.isdigit():
            return False

        slot_num = int(slot_str)
        raw_slots = getattr(window, "slots", None)

        if raw_slots is None:
            return False

        slots_list = list(raw_slots)
        if slot_num < 0 or slot_num >= len(slots_list):
            log(
                "GUI_ERROR",
                f"Nomor slot [{slot_num}] di luar jangkauan (Max: {len(slots_list)-1})",
            )
            return True

        try:
            if mode == "KIRI":
                self.bot.clickWindow(slot_num, 0, 0)
            elif mode == "KANAN":
                self.bot.clickWindow(slot_num, 1, 0)
            elif mode == "SHIFT":
                self.bot.clickWindow(slot_num, 0, 1)
            elif mode == "DROP":
                self.bot.clickWindow(slot_num, 0, 4)
            elif mode in ["DROP_ALL", "DROPALL"]:
                self.bot.clickWindow(slot_num, 1, 4)
            else:
                log(
                    "GUI_ERROR",
                    "Mode tidak valid! Gunakan: KIRI, KANAN, SHIFT, DROP, TO, atau DROP_ALL_INV",
                )
        except Exception as e:
            log("GUI_ERROR", f"Gagal mengeksekusi klik pada GUI: {e}")

        return True

    def _handle_drop_all_inv(self, raw_cmd: str):
        inventory = getattr(self.bot, "inventory", None)
        if not inventory:
            log("GUI_WARN", "Inventory belum siap.")
            return

        slots_attr = getattr(inventory, "slots", None)
        if not slots_attr:
            return

        slots_list = list(slots_attr)

        CATEGORY_SLOTS = {
            "armor": {5, 6, 7, 8},
            "craft": {0, 1, 2, 3, 4},
            "crafting": {0, 1, 2, 3, 4},
            "offhand": {45},
            "inv": set(range(9, 45)),
        }

        protected_slots = set()
        target_only_slots = set()

        type_mode = None
        slot_mode = None
        delay_sec = 0.12

        raw_flags = raw_cmd.split("--")

        for flag in raw_flags[1:]:
            flag = flag.strip()

            if flag.lower().startswith("delay="):
                val_str = flag[6:].strip().lower()

                if val_str.endswith("s"):
                    try:
                        delay_sec = float(val_str[:-1])
                    except ValueError:
                        log(
                            "GUI_ERROR",
                            f"Format delay detik '{val_str}' tidak valid!",
                        )
                        return
                elif val_str.endswith("t"):
                    try:
                        ticks = float(val_str[:-1])
                        delay_sec = ticks * 0.05
                    except ValueError:
                        log(
                            "GUI_ERROR",
                            f"Format delay tick '{val_str}' tidak valid!",
                        )
                        return
                else:
                    log(
                        "GUI_ERROR",
                        f"Format delay '{val_str}' salah! Gunakan akhiran 's' atau 't'.",
                    )
                    return

                if delay_sec < 0:
                    log("GUI_ERROR", "Delay tidak boleh bernilai negatif!")
                    return

            elif flag.lower().startswith("type="):
                val_str = flag[5:].strip()
                tokens = [
                    t.strip() for t in val_str.split(",") if t.strip()
                ]

                for tok in tokens:
                    is_ex = tok.startswith("!")
                    clean_tok = tok.lstrip("!").lower()

                    if clean_tok not in CATEGORY_SLOTS:
                        log(
                            "GUI_ERROR",
                            f"Type '{clean_tok}' tidak dikenal! Pilih: armor, craft, offhand, inv",
                        )
                        return

                    if type_mode is None:
                        type_mode = is_ex
                    elif type_mode != is_ex:
                        log(
                            "GUI_ERROR",
                            "Tidak boleh mencampur '!' dan tanpa '!' di --type.",
                        )
                        return

                    target_set = (
                        protected_slots if is_ex else target_only_slots
                    )
                    target_set.update(CATEGORY_SLOTS[clean_tok])

            elif flag.lower().startswith("slot="):
                val_str = flag[5:].strip()
                tokens = [
                    t.strip() for t in val_str.split(",") if t.strip()
                ]

                for tok in tokens:
                    is_ex = tok.startswith("!")
                    num_str = tok.lstrip("!")

                    if not num_str.isdigit():
                        log(
                            "GUI_ERROR",
                            f"Slot '{num_str}' bukan angka yang valid!",
                        )
                        return

                    if slot_mode is None:
                        slot_mode = is_ex
                    elif slot_mode != is_ex:
                        log(
                            "GUI_ERROR",
                            "Tidak boleh mencampur '!' dan tanpa '!' di --slot.",
                        )
                        return

                    slot_num = int(num_str)
                    target_set = (
                        protected_slots if is_ex else target_only_slots
                    )
                    target_set.add(slot_num)

        def drop_process():
            mode_desc = []
            if protected_slots:
                mode_desc.append(
                    f"EXCLUDE {len(protected_slots)} slot terproteksi"
                )
            if target_only_slots:
                mode_desc.append(
                    f"TARGET ONLY {len(target_only_slots)} slot khusus"
                )

            log(
                "GUI",
                f"Memulai DROP_ALL_INV ({', '.join(mode_desc) if mode_desc else 'ALL SLOT'}) dengan delay {delay_sec:.2f}s...",
            )
            dropped_count = 0

            for index, item in enumerate(slots_list):
                if not item:
                    continue

                if target_only_slots and index not in target_only_slots:
                    continue

                if index in protected_slots:
                    continue

                try:
                    self.bot.clickWindow(index, 1, 4)
                    dropped_count += 1
                    time.sleep(delay_sec)
                except Exception as e:
                    log("GUI_ERROR", f"Gagal drop slot [{index}]: {e}")

            log(
                "GUI",
                f"Selesai! Berhasil membuang item dari {dropped_count} slot.",
            )

            if self.gui.active_window == inventory:
                self.gui.show_player_inventory()

        threading.Thread(target=drop_process, daemon=True).start()

    def start_terminal_listener(self):
        if self.listener_started:
            return
        self.listener_started = True

        def loop():
            session = PromptSession()
            time.sleep(1)

            with patch_stdout():
                while True:
                    try:
                        user_input = session.prompt("> ")
                        user_input = user_input.strip()

                        if not user_input:
                            continue

                        # 1. Input parser saat GUI terbuka
                        if self.gui.active_window:
                            if self._handle_gui_input(user_input):
                                continue

                        if user_input.startswith("\\"):
                            parts = user_input.split(maxsplit=1)
                            cmd_name = parts[0].lower()

                            if cmd_name == "\\look":
                                self._handle_look_cmd(user_input)
                            elif cmd_name in ["\\detectplayer", "\\detect"]:
                                self._handle_detectplayer_cmd(user_input)
                            elif cmd_name in self.commands:
                                self.commands[cmd_name]()
                            elif user_input in self.commands:
                                self.commands[user_input]()
                            else:
                                log("WARN", f"Command '{cmd_name}' tidak dikenal! Ketik: \\help")
                            continue

                        # 3. Penanganan Khusus Pindah Server
                        if user_input.startswith("/server"):
                            self.bot.chat(user_input)
                            log(
                                "SYSTEM",
                                "Mengirim perintah perpindahan server...",
                            )

                            def on_spawn_after_server(*args):
                                log(
                                    "SYSTEM",
                                    "Masuk ke dunia baru, menyinkronkan data...",
                                )

                            self.bot.once("spawn", on_spawn_after_server(*args))
                            continue

                        # 4. Chat biasa / Perintah Server
                        self.bot.chat(user_input)

                    except (EOFError, KeyboardInterrupt):
                        break
                    except Exception as e:
                        log("ERROR", f"Terminal Listener Error: {e}")

        t = threading.Thread(target=loop, daemon=True)
        t.start()
