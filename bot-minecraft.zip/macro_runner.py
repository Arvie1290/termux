import time
from logger import log

class MacroRunner:
    def __init__(self, bot):
        self.bot = bot

    def is_bot_online(self):
        # Memastikan entity bot masih ada dan socket terhubung
        return hasattr(self, 'bot') and self.bot and getattr(self.bot, 'entity', None) is not None

    def relxmc(self):
        log("MACRO", "Connecting ke EcoPVP...")
        self.bot.chat("/server ecocpvp")
        
        # Jeda waktu untuk memberikan server jeda transfer socket (2-3 detik)
        time.sleep(2.5)

        # Cek apakah bot masih terhubung setelah perintah /server
        if not self.is_bot_online():
            log("MACRO_WARN", "Bot terputus saat perpindahan subserver. Macro dibatalkan.")
            return

        # Trik pergerakan halus agar /shop tidak di-drop anti-bot
        try:
            self.bot.swingArm("right")
        except Exception:
            pass
            
        time.sleep(0.3)
        
        if self.is_bot_online():
            log("MACRO", "Membuka Shop...")
            self.bot.chat("/shop")
