import sys
import time
from javascript import require, On
from logger import log
from gui_handler import GUIHandler
from commands import CommandHandler
from macro_runner import MacroRunner

mineflayer = require('mineflayer')

BOT_CONFIG = {
    'host': 'relxmc.com',
    'port': 25565,
    'username': 'AkuMewing123',
    'auth': 'offline',
    'hideErrors': True,
    'checkTimeoutInterval': 60 * 1000
}

def main():
    log("SYSTEM", f"Connecting to {BOT_CONFIG['host']}:{BOT_CONFIG['port']}...")
    
    try:
        bot = mineflayer.createBot(BOT_CONFIG)
    except Exception as e:
        log("ERROR", f"Gagal membuat instance bot: {e}")
        return

    gui = GUIHandler(bot)
    macro = MacroRunner(bot)
    cmd = CommandHandler(bot, gui, macro)

    gui.setup_listeners()

    @On(bot, 'spawn')
    def on_spawn(this):
        log("SYSTEM", "Bot berhasil masuk ke world!")
        cmd.start_terminal_listener()

    @On(bot, 'message')
    def on_message(this, message, position, sender, *args):
        try:
            clean_text = message.toString()
            log("SERVER", clean_text)
        except Exception:
            pass

    @On(bot, 'kicked')
    def on_kicked(this, reason, loggedIn, *args):
        log("SYSTEM_WARNING", f"Bot di-kick dari server: {reason}")

    @On(bot, 'end')
    def on_end(this, reason, *args):
        log("SYSTEM", f"Bot terputus dari server. Alasan: {reason}")
        if hasattr(gui, 'active_window'):
            gui.active_window = None

    @On(bot, 'error')
    def on_error(this, err, *args):
        log("ERROR", f"Mineflayer Error: {err}")

    # Keep alive loop agar proses Python tidak exit
    log("SYSTEM", "Memulai keep-alive loop...")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        log("SYSTEM", "Bot dihentikan oleh user.")

if __name__ == "__main__":
    main()
