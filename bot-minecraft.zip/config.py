import os

# Configuration Settings
BOT_USERNAME = "AkuMewing123"
SERVER_IP = "relxmc.com"
SERVER_PORT = 25565

# Trusted players (Abaikan deteksi & kirim pesan peringatan ke mereka)
TRUSTED_PLAYERS = ["gamercaz", "idk1290"]
