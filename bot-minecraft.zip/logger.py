import sys

def log(tag, message):
    """
    Mencetak log secara bersih. Kompatibel dengan patch_stdout dari prompt_toolkit.
    """
    print(f"[{tag}] {message}")
    sys.stdout.flush()