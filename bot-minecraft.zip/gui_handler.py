import json
import threading
import time
from logger import log


class GUIHandler:

    def __init__(self, bot):
        self.bot = bot
        self.active_window = None

    def setup_listeners(self):
        def on_respawn(*args):
            if self.active_window:
                log("GUI", "Reset state GUI (Pindah subserver/world).")
                self.active_window = None

        def on_window_close(*args):
            self.active_window = None
            log("GUI", "GUI ditutup.")

        def on_window_open(window_arg, *args):
            target_window = getattr(self.bot, "currentWindow", None)
            if not target_window:
                target_window = window_arg

            self.active_window = target_window

            w_title_raw = getattr(target_window, "title", "Container GUI")
            w_type = getattr(target_window, "type", "N/A")

            log(
                "GUI",
                f"Terbuka: {self._clean_title(w_title_raw)} (Type: {w_type}) - Syncing items...",
            )

            rendered = False
            lock = threading.Lock()

            def try_render():
                nonlocal rendered
                with lock:
                    if rendered:
                        return True

                    curr_win = getattr(self.bot, "currentWindow", None)
                    if not curr_win:
                        return False

                    slots_attr = getattr(curr_win, "slots", None)
                    slots_list = []

                    if slots_attr is not None:
                        try:
                            slots_list = list(slots_attr)
                        except Exception as e:
                            log("DEBUG", f"Gagal casting slots: {e}")

                    if len(slots_list) > 0:
                        rendered = True
                        self.print_gui_slots(slots_list, w_title_raw)
                        return True
                    return False

            def poll_slots():
                attempts = 0
                while attempts < 15:
                    time.sleep(0.15)
                    if not getattr(self.bot, "currentWindow", None):
                        break
                    if try_render():
                        break
                    attempts += 1

                if getattr(self.bot, "currentWindow", None) and not rendered:
                    log(
                        "GUI_WARN",
                        "Window terbuka tapi slot gagal dimuat/kosong.",
                    )

            threading.Thread(target=poll_slots, daemon=True).start()

        self.bot.on("respawn", on_respawn)
        self.bot.on("windowClose", on_window_close)
        self.bot.on("windowOpen", on_window_open)

    def _clean_title(self, title):
        if isinstance(title, dict) and "value" in title:
            return str(title["value"])
        elif hasattr(title, "value"):
            return str(title.value)
        return str(title)

    def _parse_chat_component(self, comp):
        if not comp:
            return ""

        if isinstance(comp, str):
            if comp.startswith("{"):
                try:
                    parsed = json.loads(comp)
                    return self._parse_chat_component(parsed)
                except:
                    return comp
            return comp

        res = ""
        val = (
            comp.get("value", comp)
            if isinstance(comp, dict)
            else getattr(comp, "value", comp)
        )
        if not isinstance(val, dict):
            val = comp

        text_val = (
            val.get("text", "")
            if isinstance(val, dict)
            else getattr(val, "text", "")
        )
        if isinstance(text_val, dict) and "value" in text_val:
            text_val = text_val["value"]
        elif hasattr(text_val, "value"):
            text_val = text_val.value

        if text_val and isinstance(text_val, str):
            res += text_val

        extra_val = (
            val.get("extra", None)
            if isinstance(val, dict)
            else getattr(val, "extra", None)
        )
        if extra_val:
            items = (
                extra_val.get("value", [])
                if isinstance(extra_val, dict)
                else getattr(extra_val, "value", [])
            )
            if hasattr(items, "value"):
                items = items.value

            if isinstance(items, (list, tuple)):
                for sub in items:
                    res += self._parse_chat_component(sub)

        return res

    def _extract_item_details(self, item):
        if not item:
            return None, []

        title = getattr(item, "displayName", None)
        nbt = getattr(item, "nbt", None)
        if nbt:
            try:
                value = (
                    nbt.get("value", {})
                    if isinstance(nbt, dict)
                    else getattr(nbt, "value", {})
                )
                display_tag = (
                    value.get("display", {}).get("value", {})
                    if isinstance(value, dict)
                    else {}
                )

                if "Name" in display_tag:
                    raw_name = display_tag["Name"]
                    parsed_title = self._parse_chat_component(raw_name)
                    if parsed_title.strip():
                        title = parsed_title
            except Exception:
                pass

        if not title:
            title = getattr(item, "name", "Air")

        lore_list = []
        custom_lore = getattr(item, "customLore", None)
        if custom_lore:
            try:
                for line in list(custom_lore):
                    clean_line = self._parse_chat_component(line)
                    if clean_line.strip():
                        lore_list.append(clean_line)
            except Exception:
                pass

        if not lore_list and nbt:
            try:
                value = (
                    nbt.get("value", {})
                    if isinstance(nbt, dict)
                    else getattr(nbt, "value", {})
                )
                display_tag = (
                    value.get("display", {}).get("value", {})
                    if isinstance(value, dict)
                    else {}
                )

                if "Lore" in display_tag:
                    lore_compound = display_tag["Lore"]
                    raw_lore_list = (
                        lore_compound.get("value", {}).get("value", [])
                        if isinstance(lore_compound, dict)
                        else getattr(lore_compound, "value", [])
                    )

                    if hasattr(raw_lore_list, "value"):
                        raw_lore_list = raw_lore_list.value

                    if isinstance(raw_lore_list, (list, tuple)):
                        for line in raw_lore_list:
                            clean_line = self._parse_chat_component(line)
                            if clean_line.strip():
                                lore_list.append(clean_line)
            except Exception:
                pass

        return str(title), lore_list

    def print_gui_slots(self, slots_list, title="GUI Container"):
        clean_title = self._clean_title(title)

        print("\n" + "=" * 60)
        print(f" 📦 GUI: {clean_title.upper()}")
        print("=" * 60)

        curr_win = getattr(self.bot, "currentWindow", None)
        inventory_start = (
            getattr(curr_win, "inventoryStart", None) if curr_win else None
        )

        has_item = False
        if slots_list:
            for index, item in enumerate(slots_list):
                if inventory_start is not None and index >= inventory_start:
                    break

                if item:
                    has_item = True
                    item_raw_name = getattr(item, "name", "unknown")
                    item_count = getattr(item, "count", 1)

                    display_title, lore = self._extract_item_details(item)

                    print(
                        f" Slot [{index:02d}] : {display_title} (x{item_count}) -> [{item_raw_name}]"
                    )

                    if lore:
                        for line in lore:
                            print(f"           💬 {line}")

        if not has_item:
            print(" ⚠️ (Tidak ada item di dalam container ini)")

        print("=" * 60)
        print(" 🎮 CARA INTERAKSI INTERAKTIF:")
        print(" • [slot]                   - mengklik slot itu dengan klik kiri")
        print(" • [slot] KIRI / KANAN / SHIFT / DROP / DROP_ALL")
        print(" • [slot_asal] TO [slot_tujuan] - pindahkan item antar slot")
        print(" • EXIT / ESC               - menutup GUI")
        print("=" * 60 + "\n")

    def show_player_inventory(self):
        """Membuka Inventory Player sebagai Interactive GUI"""
        inventory = getattr(self.bot, "inventory", None)
        if not inventory:
            log("GUI_WARN", "Inventory player belum dimuat/siap.")
            return

        # Set active_window ke inventory player agar bisa diinteraksi
        self.active_window = inventory

        slots_attr = getattr(inventory, "slots", None)
        slots_list = list(slots_attr) if slots_attr else []

        # Mapping label slot khusus
        special_slots = {
            0: "Crafting Result",
            1: "Crafting Grid (1)",
            2: "Crafting Grid (2)",
            3: "Crafting Grid (3)",
            4: "Crafting Grid (4)",
            5: "Armor (Helmet)",
            6: "Armor (Chestplate)",
            7: "Armor (Leggings)",
            8: "Armor (Boots)",
            45: "Offhand",
        }

        print("\n" + "=" * 60)
        print(" 🎒 INVENTORY PLAYER BOT (INTERAKSI AKTIF)")
        print("=" * 60)

        # 1. Tampilkan Slot Khusus (Crafting 2x2, Armor, Offhand)
        print(" 🛡️ SLOT KHUSUS & EQUIPMENT:")
        for slot_idx, label in special_slots.items():
            item = (
                slots_list[slot_idx] if slot_idx < len(slots_list) else None
            )
            if item:
                item_raw_name = getattr(item, "name", "unknown")
                item_count = getattr(item, "count", 1)
                display_title, lore = self._extract_item_details(item)
                print(
                    f" Slot [{slot_idx:02d}] ({label}) : {display_title} (x{item_count}) -> [{item_raw_name}]"
                )
                if lore:
                    for line in lore:
                        print(f"           💬 {line}")
            else:
                print(f" Slot [{slot_idx:02d}] ({label}) : (None)")

        print("-" * 60)
        print(" 📦 MAIN INVENTORY & HOTBAR:")

        # 2. Tampilkan Isi Storage (Slot 9 - 44)
        has_main_item = False
        for index in range(9, 45):
            if index < len(slots_list) and slots_list[index]:
                item = slots_list[index]
                has_main_item = True
                item_raw_name = getattr(item, "name", "unknown")
                item_count = getattr(item, "count", 1)
                display_title, lore = self._extract_item_details(item)

                label = "Hotbar" if 36 <= index <= 44 else "Main Inv"
                print(
                    f" Slot [{index:02d}] ({label}) : {display_title} (x{item_count}) -> [{item_raw_name}]"
                )
                if lore:
                    for line in lore:
                        print(f"           💬 {line}")

        if not has_main_item:
            print(" ⚠️ (Main inventory & hotbar kosong)")

        print("=" * 60)
        print(" 🎮 CARA INTERAKSI INTERAKTIF:")
        print(" • [slot]                   - mengklik slot itu dengan klik kiri")
        print(" • [slot] KIRI / KANAN / SHIFT / DROP / DROP_ALL")
        print(" • [slot_asal] TO [slot_tujuan] - pindahkan item antar slot")
        print(" • DROP_ALL_INV             - buang massal isi inventory")
        print("   Flags:")
        print("   • --type=!armor,!craft,!offhand,!inv (Mode Exclude)")
        print("   • --type=armor,craft (Mode Include/Target Only)")
        print("   • --slot=!36,!37 ATAU --slot=36,37")
        print("   • --delay=0.5s ATAU --delay=10t")
        print(" • EXIT / ESC               - menutup GUI")
        print("=" * 60 + "\n")
